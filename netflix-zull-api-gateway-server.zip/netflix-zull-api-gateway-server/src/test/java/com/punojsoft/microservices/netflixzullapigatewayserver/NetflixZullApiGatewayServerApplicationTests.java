package com.punojsoft.microservices.netflixzullapigatewayserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NetflixZullApiGatewayServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
