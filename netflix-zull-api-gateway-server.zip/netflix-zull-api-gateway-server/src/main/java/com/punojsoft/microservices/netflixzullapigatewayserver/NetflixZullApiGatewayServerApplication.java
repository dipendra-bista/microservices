package com.punojsoft.microservices.netflixzullapigatewayserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NetflixZullApiGatewayServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(NetflixZullApiGatewayServerApplication.class, args);
	}

}
